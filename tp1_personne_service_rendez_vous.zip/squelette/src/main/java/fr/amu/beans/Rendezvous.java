package fr.amu.beans;

import java.io.Serializable;
import java.util.ArrayList;

public class Rendezvous implements Serializable {
	private int duree;
	private ArrayList<String> personnes;
	private String lieu;
	private String type;
	
	public int getDuree() {
		return duree;
	}

	public ArrayList<String> getPersonnes() {
		return personnes;
	}

	public void setPersonnes(ArrayList<String> personnes) {
		this.personnes = personnes;
	}

	public String getLieu() {
		return lieu;
	}

	public void setLieu(String lieu) {
		this.lieu = lieu;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public void setDuree(int duree) {
		this.duree = duree;
	}
	
	 public Rendezvous() {
		// TODO Auto-generated constructor stub
	}
	//methode retournant la liste de personne 
	public int NombrePersonne() {
	
		return this.getPersonnes().size();
	}
}
