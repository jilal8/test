package fr.amu.Services;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.common.base.Joiner;

import fr.amu.Application;
import fr.amu.beans.Rendezvous;

public class RendezvousService {
	private static final Logger log = LoggerFactory.getLogger(Application.class);
	private ArrayList<Rendezvous> listeRendezVous = new ArrayList<Rendezvous>();
	
	public RendezvousService() {
		
			Rendezvous rdv = new Rendezvous();
			rdv.setDuree(9);
			rdv.setLieu("Marseille");
			rdv.setType("entretien d'embauche.");
			ArrayList<String> personnes = new ArrayList<>();
			personnes.add("loko");
			personnes.add("loko1");
			personnes.add("loko2");
			personnes.add("loko-tacos");
			rdv.setPersonnes(personnes);
			Rendezvous rdv1 = new Rendezvous();
			rdv1.setDuree(9);
			rdv1.setLieu("Lyon");
			rdv1.setType("entretien.");
			personnes.add("loko");
			personnes.add("loko11");
			personnes.add("loko22");
			personnes.add("loko-tacos1");
			rdv1.setPersonnes(personnes);
			listeRendezVous.add(rdv);
			listeRendezVous.add(rdv1);
	}
	
	public void addRdv(Rendezvous rdv) {
		this.listeRendezVous.add(rdv);
	}
	
	public int getNombreRdv() {
		return listeRendezVous.size();
	}
	
	public ArrayList<Rendezvous> recupereRDV(ArrayList<String> types){
		
		ArrayList<Rendezvous> rdv = new ArrayList<>();
		
		for (Rendezvous rendezvous : this.listeRendezVous) {
			if(types.contains(rendezvous.getType())) {
				rdv.add(rendezvous);
			}
		}
		
		return rdv;
	}
	public void afficher() {
		for (Rendezvous rendezvous : listeRendezVous) {
			log.info(String.format("%s%s%s%s", String.valueOf(rendezvous.getDuree()), rendezvous.getLieu(), rendezvous.getType(), Joiner.on(", ").join(rendezvous.getPersonnes())));
//			log.info(rendezvous.getDuree()+" "+rendezvous.getLieu()+" "+rendezvous.getType()+" ");
//			for (String personne : rendezvous.getPersonnes()) {
//				log.info(personne+" ");
//			}
//			System.out.println();
}
	}
}
